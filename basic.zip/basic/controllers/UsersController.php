<?php

namespace app\controllers;

use yii\web\Controller;
use app\models\Utilizador;

class UsersController extends Controller {

    public function actionIndex(){
    $utilizador = Utilizador::find()->all();
    
    $this->render('index',['utilizador'=>$utilizador]);

    }
}