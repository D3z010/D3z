<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pontos".
 *
 * @property int $id_ponto
 * @property int $minuto
 * @property int|null $tipo_ponto
 * @property int $Jogo_id_jogo
 * @property int $Jogador_id_jogador
 *
 * @property Jogador $jogadorIdJogador
 * @property Jogo $jogoIdJogo
 */
class Pontos extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pontos';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['minuto', 'Jogo_id_jogo', 'Jogador_id_jogador'], 'required'],
            [['minuto', 'tipo_ponto', 'Jogo_id_jogo', 'Jogador_id_jogador'], 'integer'],
            [['Jogador_id_jogador'], 'exist', 'skipOnError' => true, 'targetClass' => Jogador::className(), 'targetAttribute' => ['Jogador_id_jogador' => 'id_jogador']],
            [['Jogo_id_jogo'], 'exist', 'skipOnError' => true, 'targetClass' => Jogo::className(), 'targetAttribute' => ['Jogo_id_jogo' => 'id_jogo']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_ponto' => 'Id Ponto',
            'minuto' => 'Minuto',
            'tipo_ponto' => 'Tipo Ponto',
            'Jogo_id_jogo' => 'Jogo Id Jogo',
            'Jogador_id_jogador' => 'Jogador Id Jogador',
        ];
    }

    /**
     * Gets query for [[JogadorIdJogador]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogadorIdJogador()
    {
        return $this->hasOne(Jogador::className(), ['id_jogador' => 'Jogador_id_jogador']);
    }

    /**
     * Gets query for [[JogoIdJogo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogoIdJogo()
    {
        return $this->hasOne(Jogo::className(), ['id_jogo' => 'Jogo_id_jogo']);
    }
}
