<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "faltas".
 *
 * @property int $id_falta
 * @property int $minuto
 * @property string $tipo_falta
 * @property int $Jogo_id_jogo
 * @property int|null $Jogador_id_jogador
 * @property int|null $Treinador_id_treinador
 *
 * @property Jogador $jogadorIdJogador
 * @property Jogo $jogoIdJogo
 * @property Treinador $treinadorIdTreinador
 */
class Faltas extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'faltas';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['minuto', 'tipo_falta', 'Jogo_id_jogo'], 'required'],
            [['minuto', 'Jogo_id_jogo', 'Jogador_id_jogador', 'Treinador_id_treinador'], 'integer'],
            [['tipo_falta'], 'string', 'max' => 10],
            [['Jogador_id_jogador'], 'exist', 'skipOnError' => true, 'targetClass' => Jogador::className(), 'targetAttribute' => ['Jogador_id_jogador' => 'id_jogador']],
            [['Jogo_id_jogo'], 'exist', 'skipOnError' => true, 'targetClass' => Jogo::className(), 'targetAttribute' => ['Jogo_id_jogo' => 'id_jogo']],
            [['Treinador_id_treinador'], 'exist', 'skipOnError' => true, 'targetClass' => Treinador::className(), 'targetAttribute' => ['Treinador_id_treinador' => 'id_treinador']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_falta' => 'Id Falta',
            'minuto' => 'Minuto',
            'tipo_falta' => 'Tipo Falta',
            'Jogo_id_jogo' => 'Jogo Id Jogo',
            'Jogador_id_jogador' => 'Jogador Id Jogador',
            'Treinador_id_treinador' => 'Treinador Id Treinador',
        ];
    }

    /**
     * Gets query for [[JogadorIdJogador]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogadorIdJogador()
    {
        return $this->hasOne(Jogador::className(), ['id_jogador' => 'Jogador_id_jogador']);
    }

    /**
     * Gets query for [[JogoIdJogo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogoIdJogo()
    {
        return $this->hasOne(Jogo::className(), ['id_jogo' => 'Jogo_id_jogo']);
    }

    /**
     * Gets query for [[TreinadorIdTreinador]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTreinadorIdTreinador()
    {
        return $this->hasOne(Treinador::className(), ['id_treinador' => 'Treinador_id_treinador']);
    }
}
