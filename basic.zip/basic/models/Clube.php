<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "clube".
 *
 * @property int $id_selecao
 * @property string $nome_selecao
 * @property string|null $genero
 * @property int $Escalão_id_escalao
 * @property int $Treinador_id_treinador
 *
 * @property Escalao $escalãoIdEscalao
 * @property Treinador $treinadorIdTreinador
 * @property Jogo[] $jogos
 * @property Jogo[] $jogos0
 * @property SelecaoJogador[] $selecaoJogadors
 * @property Jogador[] $jogadorIdJogadors
 */
class Clube extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'clube';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nome_selecao', 'Escalão_id_escalao', 'Treinador_id_treinador'], 'required'],
            [['Escalão_id_escalao', 'Treinador_id_treinador'], 'integer'],
            [['nome_selecao'], 'string', 'max' => 20],
            [['genero'], 'string', 'max' => 15],
            [['Escalão_id_escalao'], 'exist', 'skipOnError' => true, 'targetClass' => Escalao::className(), 'targetAttribute' => ['Escalão_id_escalao' => 'id_escalao']],
            [['Treinador_id_treinador'], 'exist', 'skipOnError' => true, 'targetClass' => Treinador::className(), 'targetAttribute' => ['Treinador_id_treinador' => 'id_treinador']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_selecao' => 'Id Selecao',
            'nome_selecao' => 'Nome Selecao',
            'genero' => 'Genero',
            'Escalão_id_escalao' => 'Escalão Id Escalao',
            'Treinador_id_treinador' => 'Treinador Id Treinador',
        ];
    }

    /**
     * Gets query for [[EscalãoIdEscalao]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEscalãoIdEscalao()
    {
        return $this->hasOne(Escalao::className(), ['id_escalao' => 'Escalão_id_escalao']);
    }

    /**
     * Gets query for [[EscalãoIdEscalao]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEscalãoNomeEscalao()
    {
        return $this->hasOne(Escalao::className(), ['id_escalao' => 'Escalão_nome_escalao']);
    }

    /**
     * Gets query for [[TreinadorIdTreinador]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTreinadorIdTreinador()
    {
        return $this->hasOne(Treinador::className(), ['id_treinador' => 'Treinador_id_treinador']);
    }

    /**
     * Gets query for [[TreinadorIdTreinador]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTreinadorNomeTreinador()
    {
        return $this->hasOne(Treinador::className(), ['id_treinador' => 'Treinador_nome_treinador']);
    }

    

    /**
     * Gets query for [[Jogos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogos()
    {
        return $this->hasMany(Jogo::className(), ['Seleção_id_selecao1' => 'id_selecao']);
    }

    /**
     * Gets query for [[Jogos0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogos0()
    {
        return $this->hasMany(Jogo::className(), ['Seleção_id_selecao2' => 'id_selecao']);
    }

    /**
     * Gets query for [[SelecaoJogadors]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSelecaoJogadors()
    {
        return $this->hasMany(SelecaoJogador::className(), ['Seleção_id_selecao' => 'id_selecao']);
    }

    /**
     * Gets query for [[JogadorIdJogadors]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogadorIdJogadors()
    {
        return $this->hasMany(Jogador::className(), ['id_jogador' => 'Jogador_id_jogador'])->viaTable('selecao_jogador', ['Seleção_id_selecao' => 'id_selecao']);
    }
}
