<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "divisao".
 *
 * @property int $id_divisao
 * @property string $nome_divisao
 * @property string|null $descricao_divisao
 *
 * @property Escalao[] $escalaos
 */
class Divisao extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'divisao';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nome_divisao'], 'required'],
            [['nome_divisao'], 'string', 'max' => 20],
            [['descricao_divisao'], 'string', 'max' => 150],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_divisao' => 'Id Divisao',
            'nome_divisao' => 'Nome Divisao',
            'descricao_divisao' => 'Descricao Divisao',
        ];
    }

    /**
     * Gets query for [[Escalaos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEscalaos()
    {
        return $this->hasMany(Escalao::className(), ['Divisão_id_divisao' => 'id_divisao']);
    }
}
