<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "escalao".
 *
 * @property int $id_escalao
 * @property string $nome_escalao
 * @property string|null $descricao_escalao
 * @property int $Divisão_id_divisao
 *
 * @property Clube[] $clubes
 * @property Divisao $divisãoIdDivisao
 */
class Escalao extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'escalao';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nome_escalao', 'Divisão_id_divisao'], 'required'],
            [['Divisão_id_divisao'], 'integer'],
            [['nome_escalao'], 'string', 'max' => 20],
            [['descricao_escalao'], 'string', 'max' => 150],
            [['Divisão_id_divisao'], 'exist', 'skipOnError' => true, 'targetClass' => Divisao::className(), 'targetAttribute' => ['Divisão_id_divisao' => 'id_divisao']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_escalao' => 'Id Escalao',
            'nome_escalao' => 'Nome Escalao',
            'descricao_escalao' => 'Descricao Escalao',
            'Divisão_id_divisao' => 'Divisão Id Divisao',
        ];
    }

    /**
     * Gets query for [[Clubes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClubes()
    {
        return $this->hasMany(Clube::className(), ['Escalão_id_escalao' => 'id_escalao']);
    }

    /**
     * Gets query for [[DivisãoIdDivisao]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDivisãoIdDivisao()
    {
        return $this->hasOne(Divisao::className(), ['id_divisao' => 'Divisão_id_divisao']);
    }
}
