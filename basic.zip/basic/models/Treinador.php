<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "treinador".
 *
 * @property int $id_treinador
 * @property string|null $nome_treinador
 *
 * @property Clube[] $clubes
 * @property Faltas[] $faltas
 */
class Treinador extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'treinador';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_treinador'], 'required'],
            [['id_treinador'], 'integer'],
            [['nome_treinador'], 'string', 'max' => 45],
            [['id_treinador'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_treinador' => 'Id Treinador',
            'nome_treinador' => 'Nome Treinador',
        ];
    }

    /**
     * Gets query for [[Clubes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClubes()
    {
        return $this->hasMany(Clube::className(), ['Treinador_id_treinador' => 'id_treinador']);
    }

    /**
     * Gets query for [[Faltas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFaltas()
    {
        return $this->hasMany(Faltas::className(), ['Treinador_id_treinador' => 'id_treinador']);
    }
}
