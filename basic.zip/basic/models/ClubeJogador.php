<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "clube_jogador".
 *
 * @property int $Seleção_id_selecao
 * @property int $Jogador_id_jogador
 * @property string|null $data
 *
 * @property Jogador $jogadorIdJogador
 * @property Clube $seleçãoIdSelecao
 */
class ClubeJogador extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'clube_jogador';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Seleção_id_selecao', 'Jogador_id_jogador'], 'required'],
            [['Seleção_id_selecao', 'Jogador_id_jogador'], 'integer'],
            [['data'], 'safe'],
            [['Seleção_id_selecao', 'Jogador_id_jogador'], 'unique', 'targetAttribute' => ['Seleção_id_selecao', 'Jogador_id_jogador']],
            [['Jogador_id_jogador'], 'exist', 'skipOnError' => true, 'targetClass' => Jogador::className(), 'targetAttribute' => ['Jogador_id_jogador' => 'id_jogador']],
            [['Seleção_id_selecao'], 'exist', 'skipOnError' => true, 'targetClass' => Clube::className(), 'targetAttribute' => ['Seleção_id_selecao' => 'id_selecao']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Seleção_id_selecao' => 'Seleção Id Selecao',
            'Jogador_id_jogador' => 'Jogador Id Jogador',
            'data' => 'Data',
        ];
    }

    /**
     * Gets query for [[JogadorIdJogador]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogadorIdJogador()
    {
        return $this->hasOne(Jogador::className(), ['id_jogador' => 'Jogador_id_jogador']);
    }

    /**
     * Gets query for [[SeleçãoIdSelecao]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSeleçãoIdSelecao()
    {
        return $this->hasOne(Clube::className(), ['id_selecao' => 'Seleção_id_selecao']);
    }
}
