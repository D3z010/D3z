<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "jogador".
 *
 * @property int $id_jogador
 * @property string $nome_jogador
 * @property int|null $num_camisola
 * @property string|null $clube
 * @property string|null $data_nascimento
 * @property string|null $email
 * @property string|null $genero
 * @property int $idade
 * @property int|null $total_pontos
 *
 * @property ClubeJogador[] $clubeJogadors
 * @property Clube[] $seleçãoIdSelecaos
 * @property Faltas[] $faltas
 * @property Pontos[] $pontos
 * @property Substituicoes[] $substituicoes
 * @property Substituicoes[] $substituicoes0
 */
class Jogador extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'jogador';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_jogador', 'nome_jogador', 'idade'], 'required'],
            [['id_jogador', 'num_camisola', 'idade', 'total_pontos'], 'integer'],
            [['data_nascimento'], 'safe'],
            [['nome_jogador'], 'string', 'max' => 45],
            [['clube'], 'string', 'max' => 20],
            [['email'], 'string', 'max' => 50],
            [['genero'], 'string', 'max' => 15],
            [['id_jogador'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_jogador' => 'Id Jogador',
            'nome_jogador' => 'Nome Jogador',
            'num_camisola' => 'Num Camisola',
            'clube' => 'Clube',
            'data_nascimento' => 'Data Nascimento',
            'email' => 'Email',
            'genero' => 'Genero',
            'idade' => 'Idade',
            'total_pontos' => 'Total Pontos',
        ];
    }

    /**
     * Gets query for [[ClubeJogadors]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClubeJogadors()
    {
        return $this->hasMany(ClubeJogador::className(), ['Jogador_id_jogador' => 'id_jogador']);
    }

    /**
     * Gets query for [[SeleçãoIdSelecaos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSeleçãoIdSelecaos()
    {
        return $this->hasMany(Clube::className(), ['id_selecao' => 'Seleção_id_selecao'])->viaTable('clube_jogador', ['Jogador_id_jogador' => 'id_jogador']);
    }

    /**
     * Gets query for [[Faltas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFaltas()
    {
        return $this->hasMany(Faltas::className(), ['Jogador_id_jogador' => 'id_jogador']);
    }

    /**
     * Gets query for [[Pontos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPontos()
    {
        return $this->hasMany(Pontos::className(), ['Jogador_id_jogador' => 'id_jogador']);
    }

    /**
     * Gets query for [[Substituicoes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSubstituicoes()
    {
        return $this->hasMany(Substituicoes::className(), ['Jogador_id_jogador_sai' => 'id_jogador']);
    }

    /**
     * Gets query for [[Substituicoes0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSubstituicoes0()
    {
        return $this->hasMany(Substituicoes::className(), ['Jogador_id_jogador_entra' => 'id_jogador']);
    }
}
