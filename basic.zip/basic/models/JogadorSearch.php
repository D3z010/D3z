<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Jogador;

/**
 * JogadorSearch represents the model behind the search form of `app\models\Jogador`.
 */
class JogadorSearch extends Jogador
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_jogador', 'num_camisola', 'idade', 'total_pontos'], 'integer'],
            [['nome_jogador', 'clube', 'data_nascimento', 'email', 'genero'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Jogador::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_jogador' => $this->id_jogador,
            'num_camisola' => $this->num_camisola,
            'data_nascimento' => $this->data_nascimento,
            'idade' => $this->idade,
            'total_pontos' => $this->total_pontos,
        ]);

        $query->andFilterWhere(['like', 'nome_jogador', $this->nome_jogador])
            ->andFilterWhere(['like', 'clube', $this->clube])
            ->andFilterWhere(['like', 'email', $this->email])
            ->andFilterWhere(['like', 'genero', $this->genero]);

        return $dataProvider;
    }
}
