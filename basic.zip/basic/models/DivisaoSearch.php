<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Divisao;

/**
 * DivisaoSearch represents the model behind the search form of `app\models\Divisao`.
 */
class DivisaoSearch extends Divisao
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_divisao'], 'integer'],
            [['nome_divisao', 'descricao_divisao'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Divisao::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_divisao' => $this->id_divisao,
        ]);

        $query->andFilterWhere(['like', 'nome_divisao', $this->nome_divisao])
            ->andFilterWhere(['like', 'descricao_divisao', $this->descricao_divisao]);

        return $dataProvider;
    }
}
