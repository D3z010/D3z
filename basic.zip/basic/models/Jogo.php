<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "jogo".
 *
 * @property int $id_jogo
 * @property string $local
 * @property string $data
 * @property string $hora
 * @property string|null $resultado
 * @property int $Seleção_id_selecao1
 * @property int $Seleção_id_selecao2
 *
 * @property Faltas[] $faltas
 * @property Clube $seleçãoIdSelecao1
 * @property Clube $seleçãoIdSelecao2
 * @property Pontos[] $pontos
 * @property Substituicoes[] $substituicoes
 */
class Jogo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'jogo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['local', 'data', 'hora', 'Seleção_id_selecao1', 'Seleção_id_selecao2'], 'required'],
            [['data', 'hora'], 'safe'],
            [['Seleção_id_selecao1', 'Seleção_id_selecao2'], 'integer'],
            [['local', 'resultado'], 'string', 'max' => 45],
            [['Seleção_id_selecao1'], 'exist', 'skipOnError' => true, 'targetClass' => Clube::className(), 'targetAttribute' => ['Seleção_id_selecao1' => 'id_selecao']],
            [['Seleção_id_selecao2'], 'exist', 'skipOnError' => true, 'targetClass' => Clube::className(), 'targetAttribute' => ['Seleção_id_selecao2' => 'id_selecao']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_jogo' => 'Id Jogo',
            'local' => 'Local',
            'data' => 'Data',
            'hora' => 'Hora',
            'resultado' => 'Resultado',
            'Seleção_nome_selecao1' => 'Seleção_nome_selecao1',
            'Seleção_id_selecao1' => 'Seleção Id Selecao1',
            'Seleção_id_selecao2' => 'Seleção Id Selecao2',
        ];
    }

    /**
     * Gets query for [[Faltas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFaltas()
    {
        return $this->hasMany(Faltas::className(), ['Jogo_id_jogo' => 'id_jogo']);
    }

    /**
     * Gets query for [[SeleçãoIdSelecao1]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSeleçãoIdSelecao1()
    {
        return $this->hasOne(Clube::className(), ['id_selecao' => 'Seleção_id_selecao1']);
        //return $this->hasOne(Clube::className(), ['id_selecao' => 'Seleção_id_selecao1']);
    }

    /**
     * Gets query for [[SeleçãoNomeSelecao1]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSeleçãoNomeSelecao1()
    {
        return $this->hasOne(Clube::className(), ['id_selecao' => 'Seleção_nome_selecao1']);
        //return $this->hasOne(Clube::className(), ['id_selecao' => 'Seleção_id_selecao1']);
    }

    /**
     * Gets query for [[SeleçãoIdSelecao2]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSeleçãoIdSelecao2()
    {
        return $this->hasOne(Clube::className(), ['id_selecao' => 'Seleção_id_selecao2']);
    }

    /**
     * Gets query for [[Pontos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPontos()
    {
        return $this->hasMany(Pontos::className(), ['Jogo_id_jogo' => 'id_jogo']);
    }

    /**
     * Gets query for [[Substituicoes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSubstituicoes()
    {
        return $this->hasMany(Substituicoes::className(), ['Jogo_id_jogo' => 'id_jogo']);
    }
}
