<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "substituicoes".
 *
 * @property int $id_substituicao
 * @property int $minuto
 * @property int $Jogo_id_jogo
 * @property int $Jogador_id_jogador_sai
 * @property int $Jogador_id_jogador_entra
 *
 * @property Jogador $jogadorIdJogadorSai
 * @property Jogador $jogadorIdJogadorEntra
 * @property Jogo $jogoIdJogo
 */
class Substituicoes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'substituicoes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['minuto', 'Jogo_id_jogo', 'Jogador_id_jogador_sai', 'Jogador_id_jogador_entra'], 'required'],
            [['minuto', 'Jogo_id_jogo', 'Jogador_id_jogador_sai', 'Jogador_id_jogador_entra'], 'integer'],
            [['Jogador_id_jogador_sai'], 'exist', 'skipOnError' => true, 'targetClass' => Jogador::className(), 'targetAttribute' => ['Jogador_id_jogador_sai' => 'id_jogador']],
            [['Jogador_id_jogador_entra'], 'exist', 'skipOnError' => true, 'targetClass' => Jogador::className(), 'targetAttribute' => ['Jogador_id_jogador_entra' => 'id_jogador']],
            [['Jogo_id_jogo'], 'exist', 'skipOnError' => true, 'targetClass' => Jogo::className(), 'targetAttribute' => ['Jogo_id_jogo' => 'id_jogo']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_substituicao' => 'Id Substituicao',
            'minuto' => 'Minuto',
            'Jogo_id_jogo' => 'Jogo Id Jogo',
            'Jogador_id_jogador_sai' => 'Jogador Id Jogador Sai',
            'Jogador_id_jogador_entra' => 'Jogador Id Jogador Entra',
        ];
    }

    /**
     * Gets query for [[JogadorIdJogadorSai]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogadorIdJogadorSai()
    {
        return $this->hasOne(Jogador::className(), ['id_jogador' => 'Jogador_id_jogador_sai']);
    }

    /**
     * Gets query for [[JogadorIdJogadorEntra]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogadorIdJogadorEntra()
    {
        return $this->hasOne(Jogador::className(), ['id_jogador' => 'Jogador_id_jogador_entra']);
    }

    /**
     * Gets query for [[JogoIdJogo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getJogoIdJogo()
    {
        return $this->hasOne(Jogo::className(), ['id_jogo' => 'Jogo_id_jogo']);
    }
}
