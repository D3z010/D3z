<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Clube;

/**
 * ClubeSearch represents the model behind the search form of `app\models\Clube`.
 */
class ClubeSearch extends Clube
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_selecao', 'Escalão_id_escalao', 'Treinador_id_treinador'], 'integer'],
            [['nome_selecao', 'genero'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Clube::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_selecao' => $this->id_selecao,
            'Escalão_id_escalao' => $this->Escalão_id_escalao,
            'Treinador_id_treinador' => $this->Treinador_id_treinador,
        ]);

        $query->andFilterWhere(['like', 'nome_selecao', $this->nome_selecao])
            ->andFilterWhere(['like', 'genero', $this->genero]);

        return $dataProvider;
    }
}
