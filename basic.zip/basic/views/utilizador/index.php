<?php

foreach($utilizador as $utilizador)