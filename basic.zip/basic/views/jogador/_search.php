<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\JogadorSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="jogador-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id_jogador') ?>

    <?= $form->field($model, 'nome_jogador') ?>

    <?= $form->field($model, 'num_camisola') ?>

    <?= $form->field($model, 'clube') ?>

    <?= $form->field($model, 'data_nascimento') ?>

    <?php // echo $form->field($model, 'email') ?>

    <?php // echo $form->field($model, 'genero') ?>

    <?php // echo $form->field($model, 'idade') ?>

    <?php // echo $form->field($model, 'total_pontos') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
