<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Jogador */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="jogador-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_jogador')->textInput() ?>

    <?= $form->field($model, 'nome_jogador')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'num_camisola')->textInput() ?>

    <?= $form->field($model, 'clube')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'data_nascimento')->textInput() ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'genero')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'idade')->textInput() ?>

    <?= $form->field($model, 'total_pontos')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
