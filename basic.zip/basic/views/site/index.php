<?php

/* @var $this yii\web\View */

$this->title = 'Campeonato Distrital de Basquetebol';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Bem-vindo ao Campeonato Distrital</h1>

        <p class="lead">Não perca um jogo!</p>

        
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2><b>Clubes</b></h2>

                <p>Vejas as equipas participantes no Campeonato!</p>

                <p><a class="btn btn-default" href="http://localhost/basic/web/clube">Ir &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2><b>Jogos</b></h2>

                <p>Fique atualizado ao próximos jogos!</p>

                <p><a class="btn btn-default" href="http://localhost/basic/web/jogo">Ir &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2><b>Jogadores</b></h2>

                <p>Veja os seus jogadores favoritos!</p>

                <p><a class="btn btn-default" href="http://localhost/basic/web/jogador">Ir &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
