<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Jogo */

$this->title = $model->id_jogo;
$this->params['breadcrumbs'][] = ['label' => 'Jogos', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="jogo-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id_jogo], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id_jogo], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id_jogo',
            'local',
            'data',
            'hora',
            'resultado',
            [
                'label' => 'Nome Seleção 1',
                'value' => $model->seleçãoIdSelecao1->nome_selecao,
            ],

            [
                'label' => 'Nome Seleção 2',
                'value' => $model->seleçãoIdSelecao2->nome_selecao,
            ],
            
            //'Seleção_id_selecao1',
            //'Seleção_id_selecao2',
        ],
    ]) ?>

</div>
