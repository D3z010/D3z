<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ClubeSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="clube-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id_selecao') ?>

    <?= $form->field($model, 'nome_selecao') ?>

    <?= $form->field($model, 'genero') ?>

    <?= $form->field($model, 'Escalão_id_escalao') ?>

    <?= $form->field($model, 'Treinador_id_treinador') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
