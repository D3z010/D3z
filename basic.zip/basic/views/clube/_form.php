<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Clube */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="clube-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nome_selecao')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'genero')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Escalão_id_escalao')->textInput() ?>

    <?= $form->field($model, 'Treinador_id_treinador')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
