<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Divisao */

$this->title = 'Update Divisao: ' . $model->id_divisao;
$this->params['breadcrumbs'][] = ['label' => 'Divisaos', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_divisao, 'url' => ['view', 'id' => $model->id_divisao]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="divisao-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
