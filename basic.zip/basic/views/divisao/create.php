<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Divisao */

$this->title = 'Create Divisao';
$this->params['breadcrumbs'][] = ['label' => 'Divisaos', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="divisao-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
